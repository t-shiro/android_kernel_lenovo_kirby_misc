/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (c) 2020-2021, The Linux Foundation. All rights reserved.
 * Stub header for adsp_sleepmon UAPI
 */
#ifndef _UAPI_MISC_ADSP_SLEEPMON_H_
#define _UAPI_MISC_ADSP_SLEEPMON_H_

#include <linux/ioctl.h>
#include <linux/types.h>

#define ADSPSLEEPMON_DEVICE_NAME    "/dev/adsp_sleepmon"

#define ADSPSLEEPMON_IOCTL_AUDIO_VER_1      1

#define ADSPSLEEPMON_AUDIO_ACTIVITY_START       1
#define ADSPSLEEPMON_AUDIO_ACTIVITY_STOP        2
#define ADSPSLEEPMON_AUDIO_ACTIVITY_LPI_START   3
#define ADSPSLEEPMON_AUDIO_ACTIVITY_LPI_STOP    4

struct adspsleepmon_ioctl_audio {
    __u32 version;
    __u32 command;
};

#define ADSPSLEEPMON_IOC_MAGIC      'S'
#define ADSPSLEEPMON_IOCTL_AUDIO_ACTIVITY \
    _IOW(ADSPSLEEPMON_IOC_MAGIC, 1, struct adspsleepmon_ioctl_audio)

#endif /* _UAPI_MISC_ADSP_SLEEPMON_H_ */
