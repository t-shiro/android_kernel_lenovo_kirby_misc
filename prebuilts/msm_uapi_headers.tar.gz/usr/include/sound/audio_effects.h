/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (c) 2013-2014, The Linux Foundation. All rights reserved.
 * Qualcomm Technologies, Inc. MSM audio effects kernel UAPI.
 */
#ifndef _UAPI_MSM_AUDIO_EFFECTS_H
#define _UAPI_MSM_AUDIO_EFFECTS_H

#include <linux/types.h>
#include <linux/ioctl.h>

struct msm_hwacc_data_config {
    __u32 sample_rate;
    __u32 num_channels;
    __u32 bits_per_sample;
    __u32 num_buf;
    __u32 buf_size;
};

struct msm_hwacc_effects_config {
    struct msm_hwacc_data_config input;
    struct msm_hwacc_data_config output;
    __u32 meta_mode_enabled;
    __u32 overwrite_topology;
    __s32 topology;
};

struct msm_hwacc_buf_cfg {
    __u32 output_len;
    __u32 input_len;
};

struct msm_hwacc_buf_avail {
    __u32 output_num_avail;
    __u32 input_num_avail;
};

#define AUDIO_EFFECTS_WRITE         _IOW('U', 0xD7, unsigned int)
#define AUDIO_EFFECTS_READ          _IOR('U', 0xD8, unsigned int)
#define AUDIO_EFFECTS_SET_BUF_LEN   _IOW('U', 0xD9, struct msm_hwacc_buf_cfg)
#define AUDIO_EFFECTS_GET_BUF_AVAIL _IOR('U', 0xDA, struct msm_hwacc_buf_avail)
#define AUDIO_EFFECTS_SET_CONFIG    _IOW('U', 0xDB, struct msm_hwacc_effects_config)
#define AUDIO_EFFECTS_GET_CONFIG    _IOR('U', 0xDC, struct msm_hwacc_effects_config)

#endif /* _UAPI_MSM_AUDIO_EFFECTS_H */
