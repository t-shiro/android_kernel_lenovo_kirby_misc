/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (c) 2013-2015, The Linux Foundation. All rights reserved.
 * Qualcomm Technologies, Inc. audio offload effects UAPI.
 */
#ifndef _UAPI_MSM_DEVDEP_PARAMS_H
#define _UAPI_MSM_DEVDEP_PARAMS_H

#include <linux/types.h>

#define MAX_EQ_BANDS    12

#define Q27_UNITY       (1 << 27)
#define Q8_UNITY        (1 << 8)

#define EQ_BAND_BOOST   0

/* Size (in uint32_t units) of each parameter block */
#define BASS_BOOST_STRENGTH_PARAM_LEN       1
#define VIRTUALIZER_STRENGTH_PARAM_LEN      1
#define EQ_CONFIG_PARAM_LEN                 3   /* pregain, preset_id, num_bands */
#define EQ_CONFIG_PER_BAND_PARAM_LEN        5   /* filter_type, freq, gain, quality, idx */
#define REVERB_MODE_PARAM_LEN               1
#define REVERB_PRESET_PARAM_LEN             1
#define REVERB_WET_MIX_PARAM_LEN            1
#define REVERB_GAIN_ADJUST_PARAM_LEN        1
#define REVERB_ROOM_LEVEL_PARAM_LEN         1
#define REVERB_ROOM_HF_LEVEL_PARAM_LEN      1
#define REVERB_DECAY_TIME_PARAM_LEN         1
#define REVERB_DECAY_HF_RATIO_PARAM_LEN     1
#define REVERB_REFLECTIONS_LEVEL_PARAM_LEN  1
#define REVERB_REFLECTIONS_DELAY_PARAM_LEN  1
#define REVERB_LEVEL_PARAM_LEN              1
#define REVERB_DELAY_PARAM_LEN              1
#define REVERB_DIFFUSION_PARAM_LEN          1
#define REVERB_DENSITY_PARAM_LEN            1

/* Number of OpenSL ES reverb presets */
#define NUM_OSL_REVERB_PRESETS_SUPPORTED    6

/* Preset index for fully custom (band-level) EQ */
#define CUSTOM_OPENSL_PRESET                0

/* HPX state flags (hardware accelerator) */
#define OFFLOAD_SEND_HPX_STATE_ON   1
#define OFFLOAD_SEND_HPX_STATE_OFF  0

struct bass_boost_params {
    __u32 device;
    bool enable_flag;
    int strength;
    int mode;
};

struct pbe_params {
    __u32 device;
    bool enable_flag;
};

struct virtualizer_params {
    __u32 device;
    bool enable_flag;
    int strength;
    int out_type;
    int gain_adjust;
};

struct eq_config_params {
    __u32 eq_pregain;
    __u32 num_bands;
    int preset_id;
};

struct eq_per_band_params {
    __u32 band_idx;
    __u32 filter_type;
    __u32 freq_millihertz;
    __s32 gain_millibels;
    __u32 quality_factor;
};

struct eq_params {
    __u32 device;
    bool enable_flag;
    struct eq_config_params config;
    struct eq_per_band_params per_band_cfg[MAX_EQ_BANDS];
};

struct reverb_params {
    __u32 device;
    bool enable_flag;
    int mode;
    int preset;
    int wet_mix;
    int gain_adjust;
    int room_level;
    int room_hf_level;
    int decay_time;
    int decay_hf_ratio;
    int reflections_level;
    int reflections_delay;
    int level;
    int delay;
    int diffusion;
    int density;
};

struct soft_volume_params {
    bool enable_flag;
    __u32 master_gain;
    __u32 left_gain;
    __u32 right_gain;
};

#endif /* _UAPI_MSM_DEVDEP_PARAMS_H */
